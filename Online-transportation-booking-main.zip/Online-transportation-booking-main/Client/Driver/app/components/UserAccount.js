import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const UserAccount = () => {
  return (
    <View>
      <Text>UserAccounts</Text>
    </View>
  )
}

export default UserAccount

const styles = StyleSheet.create({})