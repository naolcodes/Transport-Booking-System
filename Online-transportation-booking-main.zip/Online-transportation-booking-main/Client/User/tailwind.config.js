module.exports = {
  content: ["./uberClone/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
